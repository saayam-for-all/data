# Mock Data Generation Project

## Overview
Generates synthetic CSV data based on schema with referential integrity.

## Features
- Faker-based realistic data
- Foreign key relationships maintained
- Scalable (100 → 40,000 rows)

## Setup
```
pip install pandas faker openpyxl
```

## Run
```
python generate_data.py --rows 100
```

## Output
CSV files will be saved in:
```
database/mock_db/
```

## Tables
- request
- help_categories
- request_guest_details
- req_add_info

## Notes
- Referential integrity maintained
- Easily extendable for new tables
