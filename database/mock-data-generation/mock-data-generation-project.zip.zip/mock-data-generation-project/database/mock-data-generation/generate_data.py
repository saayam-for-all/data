import json
import pandas as pd
import random
from faker import Faker
from datetime import datetime, timedelta
import argparse
import os

fake = Faker()

def random_date():
    start = datetime.now() - timedelta(days=365)
    return start + timedelta(days=random.randint(0, 365))

def generate_request(num_rows):
    return pd.DataFrame({"req_id": list(range(1, num_rows+1))})

def generate_help_categories():
    categories = ["Food", "Medical", "Transport", "Shelter", "Education"]
    return pd.DataFrame({
        "cat_id": list(range(1, len(categories)+1)),
        "category": categories
    })

def generate_request_guest_details(num_rows, request_ids):
    data = []
    for i in range(num_rows):
        data.append({
            "guest_id": i+1,
            "req_id": random.choice(request_ids),
            "name": fake.name(),
            "email": fake.email(),
            "phone": fake.phone_number(),
            "address": fake.address().replace("\n", ", ")
        })
    return pd.DataFrame(data)

def generate_req_add_info(num_rows, request_ids, cat_ids):
    data = []
    for i in range(num_rows):
        data.append({
            "id": i+1,
            "request_id": random.choice(request_ids),
            "cat_id": random.choice(cat_ids),
            "additional_info": fake.sentence(),
            "created_at": random_date()
        })
    return pd.DataFrame(data)

def main(rows, output_path):
    os.makedirs(output_path, exist_ok=True)

    request_df = generate_request(rows)
    help_cat_df = generate_help_categories()

    request_guest_df = generate_request_guest_details(
        rows, request_df["req_id"].tolist()
    )

    req_add_info_df = generate_req_add_info(
        rows,
        request_df["req_id"].tolist(),
        help_cat_df["cat_id"].tolist()
    )

    request_df.to_csv(f"{output_path}/request.csv", index=False)
    help_cat_df.to_csv(f"{output_path}/help_categories.csv", index=False)
    request_guest_df.to_csv(f"{output_path}/request_guest_details.csv", index=False)
    req_add_info_df.to_csv(f"{output_path}/req_add_info.csv", index=False)

    print("✅ Data generated successfully!")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--rows", type=int, default=100)
    parser.add_argument("--output", type=str, default="../mock_db")

    args = parser.parse_args()
    main(args.rows, args.output)
